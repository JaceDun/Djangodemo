#!/bin/bash


docker build -t mydemo_base:v1.0 ./base_image
docker build -t mydemo:v1.0 .
docker run -it -p 8080:8080  --name myapp --network host `docker images | grep -w 'mydemo' | awk '{print $3}'`