#!/bin/bash

#Bulid base image
docker build -t mydemo_base:v1.0 .