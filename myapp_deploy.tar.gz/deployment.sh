#!/bin/bash

#Bulid project image
docker build -t mydemo:v1.0 .

#Run project
docker run -it -p 8080:8080 --name myapp --net host `docker images | grep -w 'mydemo' | awk '{print $3}'`